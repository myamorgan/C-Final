#include <iostream> 
#include <string>
#include "functions.h"
#include "author.h"
#include "attributes.h"

 using namespace std;

 
void
Attributes::currDate ()
{
  
cout << "Finished on: " << date << endl;

}
