#pragma once
#include <string>

 using namespace std;

 
extern int gamePoint;

extern int checkPoint;

extern int &checkPointOne;

extern int &checkPointTwo;

extern int &checkPointThree;

extern int level;

extern int num;

extern int *street;

extern string player;

extern string start;

extern string inputChoiceOne;

extern string inputChoiceTwo;

extern string winChoice;

extern string loseChoice;

 
string game ();

int checkMath (int x, int y);

string win ();

string lose ();

