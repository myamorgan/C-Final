#include <iostream> 
#include <string>
#include "functions.h"
#include "author.h"
#include "attributes.h"

 using namespace std;

 
void
Author::authorName ()
{
  
cout << "Made by " << author << endl;

}
