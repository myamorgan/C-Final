#include <iostream>
#include <string>
#include "functions.h"

 string game ();

 
int
checkMath (int x, int y)
{
  
int checkPointSum = x + y;
  
return checkPointSum;

}


 
string win ()
{
  
cout << "You win, you saved the dog. Congrats!" << endl;
  
cout << "You got to checkpoint: " << checkMath (checkPoint, level) << endl;
  
cout << "Your end score is: " << checkMath (gamePoint, 100) << endl;
  
cout << "Type quit to quit game" << endl;
  
cin >> winChoice;
  
if (winChoice == "quit")
    {
      
return winChoice;
    
}
  
  else
    {
      
return winChoice;
    
}

}


 
string lose ()
{
  
cout << "Game over, you lose" << endl;
  
cout << "You got to checkpoint: " << checkMath (checkPoint, level) << endl;
  
cout << "Your end score is " << checkMath (gamePoint, 0) << endl;
  
cout << "Type quit to quit game" << endl;
  
cin >> loseChoice;
  
if (loseChoice == "quit")
    {
      
return loseChoice;
    
}
  
  else
    {
      
return loseChoice;
    
}

}


 
string game ()
{
  
cout << "Welcome to Dog Walk" << endl;
  
cout << "Enter your name:" << endl;
  
cin >> player;
  
cout << "Welcome " << player << endl;
  
cout <<
    "In this game, your job is to get the dog to the finish line ALIVE." <<
    endl;
  
cout << "If you don't get the dog across, you will lose!" << endl;
  
cout << "Type start to play" << endl;
  
while (start != "start")
    {
      
cin >> start;
      
if (start == "start")
	{
	  
cout << "We'll start the game" << endl;
	  
break;
	
 
}
      
      else
	{
	  
cout << "Goodbye." << endl;
	  
lose ();
	  
return loseChoice;
	
}
    
}
  
 
checkPointOne = 0;
  
level = 1;
  
street = &num;
  
cout << "There was a dog roaming around " << *street <<
    "th Ave. She came upon traffic and was stuck with making a quick decision "
    << endl;
  
cout << "Type stay to stay in place or type run to run forward" << endl;
  
while (inputChoiceOne != "stay" || inputChoiceOne != "run")
    {
      
cin >> inputChoiceOne;
      
if (inputChoiceOne == "stay")
	{
	  
lose ();
	  
return loseChoice;
	
}
      
if (inputChoiceOne == "run")
	{
	  
cout << "You can continue\n";
	  
break;
	
}
      
      else
	{
	  
cout << "You didn't make a choice. Please type 'stay' or 'run'" <<
	    endl;
	
}
    
}
  
checkPointTwo = 0;
  
level = 2;
  
cout << "She safely crossed through traffic but is now facing lava!!" <<
    endl;
  
cout <<
    "Type jump to jump on a rock and move forward or type stay to play it safe"
    << endl;
  
while (inputChoiceTwo != "jump" || inputChoiceTwo != "stay")
    {
      
cin >> inputChoiceTwo;
      
if (inputChoiceTwo == "jump")
	{
	  
level = 3;
	  
win ();
	  
return winChoice;
	
}
      
if (inputChoiceTwo == "stay")
	{
	  
lose ();
	  
return loseChoice;
	
}
      
      else
	{
	  
cout << "You didn't make a choice. Please type 'jump' or 'stay'" <<
	    endl;
	
}
    
}
  
return game ();

}


 
