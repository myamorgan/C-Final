#include <iostream> 
#include <string>
#include "functions.h"
#include "author.h"
#include "attributes.h"

 using namespace std;

 
int gamePoint = 0;

int checkPoint = 0;

int &checkPointOne = checkPoint;

int &checkPointTwo = checkPoint;

int &checkPointThree = checkPoint;

int level = 0;

int num = 45;

int *street;

string player = "";

string start = "";

string inputChoiceOne = "";

string inputChoiceTwo = "";

string winChoice = "";

string loseChoice = "";

 
int
main ()
{
  
Author author;
  
author.authorName ();
  
Attributes date;
  
date.currDate ();
  
cout << "\n";
  
 
game ();
  
return 0;

}


