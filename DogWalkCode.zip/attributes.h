#pragma once

 class Attributes:public Author
{

public:
void currDate ();

};
