#pragma once
#include <string>

 class Author
{

public:
void authorName ();
  
string author = "Mya Morgan";
  
string date = "12/17/2021";

 
private:
int highScore = 3;

};


 
